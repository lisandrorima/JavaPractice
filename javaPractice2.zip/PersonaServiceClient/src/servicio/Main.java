package servicio;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

public class Main {

	public static void main(String[] args) throws ServiceException, RemoteException {
		// TODO Auto-generated method stub
		PersonaService a = new PersonaServiceServiceLocator().getPersonaServicePort();
		boolean c = a.sosMayorDeEdad(19);
		System.out.println(c);
	}

}
