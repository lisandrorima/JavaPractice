package servicio;

public class PersonaServiceProxy implements servicio.PersonaService {
  private String _endpoint = null;
  private servicio.PersonaService personaService = null;
  
  public PersonaServiceProxy() {
    _initPersonaServiceProxy();
  }
  
  public PersonaServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initPersonaServiceProxy();
  }
  
  private void _initPersonaServiceProxy() {
    try {
      personaService = (new servicio.PersonaServiceServiceLocator()).getPersonaServicePort();
      if (personaService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)personaService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)personaService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (personaService != null)
      ((javax.xml.rpc.Stub)personaService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public servicio.PersonaService getPersonaService() {
    if (personaService == null)
      _initPersonaServiceProxy();
    return personaService;
  }
  
  public boolean sosMayorDeEdad(int arg0) throws java.rmi.RemoteException{
    if (personaService == null)
      _initPersonaServiceProxy();
    return personaService.sosMayorDeEdad(arg0);
  }
  
  
}