package com.example.client;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.example.domain.Persona;

public class PedidoRestClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Client client = ClientBuilder.newClient();
		
		WebTarget webTarget = client.target("http://localhost:8080/simple-service-webapp/webapi/pedido/send");
		
		Persona persona = new Persona(1, "Pablo", "Limay", 19);
		 
		Invocation.Builder invocationBuilder =  webTarget.request(MediaType.TEXT_PLAIN);
		Response response = invocationBuilder.post(Entity.entity(persona, MediaType.APPLICATION_JSON));
		 
		System.out.println(response.getStatus());
		System.out.println(response.readEntity(String.class));
	}

}
