package com.example.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.codehaus.jettison.json.JSONObject;

import com.example.domain.Persona;

public class PersonaRestClient {

	public static void main(String[] args) throws Exception {
		PersonaRestClient client = new PersonaRestClient();
		
		client.postPersona();
		client.getPrint();
		client.getPrintCrudo();
		client.getMayoriaEdad();
	}
	
	public void postPersona() {
		Client client = ClientBuilder.newClient();
		WebTarget webTarget = client.target("http://localhost:8080/simple-service-webapp/webapi/persona/").path("send");
		 
		Persona persona = new Persona(1, "Pablo", "Limay", 19);
		 
		Invocation.Builder invocationBuilder =  webTarget.request(MediaType.TEXT_PLAIN);
		Response response = invocationBuilder.post(Entity.entity(persona, MediaType.APPLICATION_JSON));
		 
		System.out.println(response.getStatus());
		System.out.println(response.readEntity(String.class));
	}
	
	public void getPrint() {
		Client client = ClientBuilder.newClient();
		WebTarget webTarget = client.target("http://localhost:8080/simple-service-webapp/webapi/persona/").path("print").path("Juan");
		 
		Invocation.Builder invocationBuilder =  webTarget.request(MediaType.APPLICATION_JSON);
		Response response = invocationBuilder.get();
		 
		System.out.println(response.getStatus());
		
		Persona persona = response.readEntity(Persona.class);
		
		System.out.println(persona);
	}
	
	public void getPrintCrudo() throws Exception {
		Client client = ClientBuilder.newClient();
		WebTarget webTarget = client.target("http://localhost:8080/simple-service-webapp/webapi/persona/").path("print").path("Juan");
		 
		Invocation.Builder invocationBuilder =  webTarget.request(MediaType.APPLICATION_JSON);
		Response response = invocationBuilder.get();
		 
		System.out.println(response.getStatus());
		
		String json = response.readEntity(String.class);
		
		System.out.println(json);
		
		JSONObject jsonObject = new JSONObject(json);
		System.out.println(jsonObject.getString("nombre"));
	}
	
	public void getMayoriaEdad() {
		Client client = ClientBuilder.newClient();
		WebTarget webTarget = client.target("http://localhost:8080/simple-service-webapp/webapi/persona/").path("edad").path("55");
		 
		Invocation.Builder invocationBuilder =  webTarget.request(MediaType.TEXT_PLAIN);
		Response response = invocationBuilder.get();
		 
		System.out.println(response.getStatus());
		
		Boolean mayor = response.readEntity(Boolean.class);
		
		System.out.println(mayor);
	}
}