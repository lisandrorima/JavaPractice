package com.example.resource;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.example.domain.Pedido;
import com.example.domain.Persona;


@Path("pedido")
public class PedidoResource {

	@POST
	@Path("/send")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response consumeJSON(Pedido pedido) {
		
		int precio = 2;
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		String formatted = df.format(new Date());
		int preciototal= precio*pedido.getCantidadSolicitada();
		String quienpidio = pedido.getNombre();
		
		return Response.status(200).entity("la fecha de entrega sera el" + formatted + 
				"el precio unitario es " + precio + "el precio total es " + preciototal ).build();
	
	}
}






