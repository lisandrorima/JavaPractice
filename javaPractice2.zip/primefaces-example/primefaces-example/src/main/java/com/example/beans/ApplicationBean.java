/**
 * 
 */
package com.example.beans;

import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author Educaci�nIT
 *
 */
@ManagedBean(name="appBean")
@ApplicationScoped
public class ApplicationBean {
	private Log log = LogFactory.getLog(this.getClass());
	
	private String moneda = "ARS";
	
	/**
	 * 
	 */
	public ApplicationBean() {
		this.log.fatal("ES FATAL");
		this.log.error("ES ERROR");
		this.log.warn("ES WARN");
		this.log.info("ES INFO");
		this.log.debug("ES DEBUG");
		this.log.trace("ES TRACE");
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}	
}