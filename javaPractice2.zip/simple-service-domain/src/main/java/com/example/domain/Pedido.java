package com.example.domain;

public class Pedido {

	private String nombre;
	private int cantidadSolicitada;
	
	public Pedido() {
		super(); // Importante!
	}
	
	public Pedido(String nombre, int cantidadSolicitada ) {
		super();
		this.setNombre(nombre);
		this.setCantidadSolicitada(cantidadSolicitada);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getCantidadSolicitada() {
		return cantidadSolicitada;
	}

	public void setCantidadSolicitada(int cantidadSolicitada) {
		this.cantidadSolicitada = cantidadSolicitada;
	}
}
