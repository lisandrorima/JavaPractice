package servicio;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public class PersonaService {

	@WebMethod
	public boolean sosMayorDeEdad(int edad) {
		boolean esMayor=false;
		
		if (edad>=18) {
			esMayor=true;
		}
		return esMayor;
	}
}
