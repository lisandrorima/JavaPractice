package lisandro.jsf;

public class AlumnoManagedBean {

	public AlumnoManagedBean() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	public AlumnoManagedBean(Alumno alumno) {
		super();
		this.alumno = alumno;
	}



	private Alumno alumno = new Alumno();

	public Alumno getAlumno() {
		return alumno;
	}

	public void setAlumno(Alumno alumno) {
		this.alumno = alumno;
	}
}
