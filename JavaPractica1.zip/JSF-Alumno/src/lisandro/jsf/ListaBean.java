package lisandro.jsf;

import java.util.ArrayList;
import java.util.List;
import com.example.domain.Site;
import com.example.service.SiteService;

public class ListaBean {


	public ListaBean() {
	
		//SiteService site = new SiteService();
		this.myList = new ArrayList<Site>();
		myList = SiteService.listarSitios();
		
	}
	
	List<Site> myList;

	public List<Site> getMyList() {
		return myList;
	}

	public void setMyList(List<Site> myList) {
		this.myList = myList;
	}


	
	
	
}
