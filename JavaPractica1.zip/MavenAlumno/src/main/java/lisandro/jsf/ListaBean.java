package lisandro.jsf;

import java.util.ArrayList;
import java.util.List;
import com.example.domain.Site;
import com.example.service.SiteService;

public class ListaBean {


	public ListaBean() {
	
		SiteService site = new SiteService();
		this.myList = new ArrayList<Site>();
		myList = site.listarSitios();
		
		
	}
	
	List<Site> myList;
	private String site;

	public List<Site> getMyList() {
		return myList;
	}

	public void setMyList(List<Site> myList) {
		this.myList = myList;
	}

	public String getSite() {
		return site;
	}

	public void setSite(String site) {
		this.site = site;
	}


	
	
	
}
