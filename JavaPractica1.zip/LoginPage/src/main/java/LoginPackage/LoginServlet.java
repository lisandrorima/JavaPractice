package LoginPackage;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	}

	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		  HttpSession sesion = request.getSession();
		  String usuario = request.getParameter("Usuario");
	      String clave = request.getParameter("clave");

	      
		if (usuario.equals("aa")&& clave.equals("aa")) {
			 response.sendRedirect("bienvenido.jsp");
			 sesion.setAttribute("error", "sin error");
			 sesion.setAttribute("user", usuario);
		}else {
			response.sendRedirect("index.jsp");
			sesion.setAttribute("error", "usuario invalido");
			
		}
	      
//		doGet(request, response);
	}

}
