package LoginPackage;

public class Usuario {

	public Usuario() {
		
	}
	
	public Usuario(String us, String clav) {
		this.Clave=clav;
		this.Usuario=us;
	}
	
	public String getClave() {
		return Clave;
	}
	public void setClave(String clave) {
		Clave = clave;
	}

	public String getUsuario() {
		return Usuario;
	}

	public void setUsuario(String usuario) {
		Usuario = usuario;
	}

	private String Clave;
	private String Usuario;
	
}
